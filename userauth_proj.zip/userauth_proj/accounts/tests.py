from django.contrib.auth.models import User
from django.test import Client, TestCase
from django.urls import reverse

class AuthFlowTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.signup_url = reverse('signup')
        self.login_url = reverse('login')
        self.dashboard_url = reverse('dashboard')

    def test_signup_then_login(self):
        # Sign up
        resp = self.client.post(self.signup_url, {
            'username': 'alice',
            'password1': 'StrongPass123!',
            'password2': 'StrongPass123!',
        })
        self.assertRedirects(resp, self.login_url)
        self.assertTrue(User.objects.filter(username='alice').exists())

        # Login
        resp = self.client.post(self.login_url, {
            'username': 'alice',
            'password': 'StrongPass123!',
        })
        self.assertRedirects(resp, self.dashboard_url)

        # Access dashboard
        resp = self.client.get(self.dashboard_url)
        self.assertEqual(resp.status_code, 200)

    def test_dashboard_requires_login(self):
        resp = self.client.get(self.dashboard_url)
        self.assertEqual(resp.status_code, 302)  # redirect to login
        self.assertIn('/login/', resp['Location'])
