from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.shortcuts import redirect, render

def signup_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()  # creates the user
            messages.success(request, "Account created! You can log in now.")
            return redirect('login')
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        form = UserCreationForm()

    return render(request, 'accounts/signup.html', {'form': form})

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()  # returns authenticated user
            login(request, user)
            messages.success(request, f"Welcome, {user.username}!")
            # If next=? present (from @login_required), respect it:
            nxt = request.GET.get('next') or request.POST.get('next')
            return redirect(nxt or 'dashboard')
        else:
            messages.error(request, "Invalid credentials. Try again.")
    else:
        form = AuthenticationForm(request)

    return render(request, 'accounts/login.html', {'form': form})

def logout_view(request):
    if request.user.is_authenticated:
        logout(request)
        messages.info(request, "You have been logged out.")
    return redirect('login')

@login_required
def dashboard(request):
    return render(request, 'accounts/dashboard.html')
